# CrashCare AI (Web App Edition)

A safety app that detects possible accidents using your phone's motion sensors, gives you a 15-second "Are you OK?" countdown, and helps you alert your emergency contacts — with **everything stored only on your phone**. No account, no server, no data leaving your device.

This version runs as a **web app**, so there's nothing to compile and no Android Studio needed — you just open it in Chrome.

## What's inside
- `index.html` — the entire app (open this directly)
- `manifest.json` + `service-worker.js` + `icons/` — optional extras that make it installable as a proper home-screen app with an offline cache

---

## 📲 How to get it on your Android phone

### Easiest way (2 minutes)
1. Send yourself the `index.html` file — e.g. upload it to Google Drive, or share it to yourself on WhatsApp/Telegram, or email it to yourself.
2. On your phone, open the file with **Chrome** (tap the file → "Open with" → Chrome).
3. Tap the **⋮ menu** (top-right in Chrome) → **"Add to Home screen"**.
4. Give it a name (e.g. "CrashCare AI") and tap **Add**.
5. You'll now have an icon on your home screen that opens the app like any other app.

### Better way — full app-like experience (installable, works offline, no browser bar)
This needs the files hosted somewhere on the web (Chrome won't treat `file://` pages as fully "installable" with offline support — only pages served over `http(s)` get that). The free way to do this:

1. Create a free GitHub account if you don't have one (github.com).
2. Create a new repository, e.g. `crashcare-ai`.
3. Upload all the files in this folder (`index.html`, `manifest.json`, `service-worker.js`, and the `icons/` folder) keeping the same folder structure.
4. Go to the repo's **Settings → Pages**, set the source to your main branch, and save. GitHub will give you a link like:
   `https://yourusername.github.io/crashcare-ai/`
5. Open that link on your phone in Chrome. This time Chrome will offer **"Install app"** automatically (or via the ⋮ menu) — this installs it with a proper full-screen app icon, no browser address bar, and it keeps working offline.

Either way works — the first method is instant, the second feels more like a "real" app.

---

## 🧠 How the detection works
The app fuses your phone's accelerometer and gyroscope into a simple confidence score (impact strength + rotation spike + a sudden-stop pattern) to reduce false alarms from normal driving/bumps. You can tune this in **Settings → AI Detection Sensitivity**.

## 🚨 About sending the SOS
Browsers can't silently send SMS messages on their own (no app can, without special system permissions) — so when the countdown ends, the app opens your phone's messaging app with the alert message and your first contact already filled in, and lists your other contacts as one-tap "Notify" buttons so you can fire them off in a couple of seconds. It's one tap per contact rather than fully silent, but nothing gets sent without you (or a countdown timeout) triggering it.

## 🔒 Privacy
Contacts, medical profile, and history are stored in your browser's local storage on your device only. Nothing is uploaded anywhere. Clearing your browser data/site data for this app will erase it, so don't clear site data if you want to keep your history.

## ⚠️ Disclaimer
This is a college/educational safety project — a simplified heuristic, not a certified crash-detection system. Always call emergency services directly if you are in real danger.
